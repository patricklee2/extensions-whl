An Azure CLI Extension to manage appservice resources


